import API from './useEffectAPI';
import React from 'react'
import './App.css'

const App = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
    <div className="mt-10">
      <h1 className="text-3xl font-semibold text-center mb-6">Random User Profile</h1>
      <API/>
    </div>
  </div>
  )
}

export default App

