// src/components/API.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://randomuser.me/api/?page=1&results=1&seed=abc');
        setUser(response.data.results[0]);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="max-w-md mx-auto bg-white rounded-md overflow-hidden shadow-black" style={{boxShadow:"2px 3px 10px white", margin:"20px"}}>
      {user && (
        <>
          <img className="w-full h-64 object-cover" style={{display:"inline"}} src={user.picture.large} alt="Profile" />
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-2">{`${user.name.first} ${user.name.last}`}</h2>
            <p className="text-gray-700 mb-4">{`${user.location.city}, ${user.location.country}`}</p>
            <div className="flex justify-between items-center">
              <span className="text-gray-500">Gender - {user.gender}</span> <br></br>
              <span className="text-gray-500">{user.phone}</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default API;
